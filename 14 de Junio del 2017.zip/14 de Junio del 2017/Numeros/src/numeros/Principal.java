/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package numeros;

import java.util.Scanner;

/**
 *
 * @author carlosc94
 */
public class Principal {
    
    public static void main(String[] args) {
        
        Operacion inprimir = new Operacion();
        Scanner entrada = new Scanner (System.in);
        
        System.out.println("Ingrese el primer numero");
        int numero = entrada.nextInt();
        System.out.println("Ingrese el segundo numero");
        int numero2 = entrada.nextInt();
        System.out.println("Ingrese la opcion que desea hacer 1/SUMA 2/RESTA 3/MULTIPLICAION 4/DIVISION");
        int opc= entrada.nextInt();
        
        inprimir.inpresion(numero,numero2,opc);
    }
    
}

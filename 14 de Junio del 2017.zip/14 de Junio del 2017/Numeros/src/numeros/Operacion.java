/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package numeros;

/**
 *
 * @author carlosc94
 */
public class Operacion {

    public void presentar_suma(int numero, int numero2) {

        int suma = numero + numero2;

        System.out.printf("La suma es %d mas %d \nes igual a %d",numero,numero2,suma);
    }

    public void presentar_resta(int numero, int numero2) {

        int resta = numero - numero2;
        System.out.printf("La resta es %d mas %d \nes igual a %d",numero,numero2,resta);

    }

    public void presentar_multiplicacion(int numero, int numero2) {

        int mult = numero * numero2;

        System.out.printf("La multiplicaion es %d mas %d \nes igual a %d",numero,numero2,mult);

    }

    public void presentar_division(int numero, int numero2) {

        int div = numero / numero2;

        System.out.printf("La division es %d mas %d \nes igual a %d",numero,numero2,div);

    }

    public void inpresion(int numero, int numero2, int opc) {

        if (opc == 1) {

            presentar_suma(numero, numero2);

        } else {

            if (opc == 2) {

                presentar_resta(numero, numero2);

            } else {

                if (opc == 3) {

                    presentar_multiplicacion(numero, numero2);

                } else {

                    if (opc == 4) {

                        presentar_division(numero, numero2);

                    }else{
                        
                        System.out.println("ESA OPCION NO EXISTE");
                    }
                }
            }

        }

    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package numeros;

import java.util.Scanner;

/**
 *
 * @author carlosc94
 */
public class Numeros {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Presenta inprimir = new Presenta();
        Scanner entrada = new Scanner(System.in);
        
        System.out.println("Ingrese su nombre");
        String minombre = entrada.nextLine();
        System.out.println("Tipo de reporte , 1/ MAYUSCULAS,2/ minusculas");
        int tipo = entrada.nextInt();

        if (tipo == 1) {

            inprimir.presentar_mayusculas(minombre);

        } else {
            if (tipo == 2) {

                inprimir.presentar_ninusculas(minombre);

            } else {
                System.out.println("No hay reporte");
            }
        }
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package numeros;

import java.util.Scanner;

/**
 *
 * @author carlosc94
 */
public class Numeros2 {
    
    public static void main(String[] args) {
        Presenta inprimir = new Presenta();
        Scanner entrada = new Scanner(System.in);
        
        System.out.println("Ingrese su nombre");
        String minombre = entrada.nextLine();
        System.out.println("Tipo de reporte , 1/ MAYUSCULAS,2/ minusculas");
        int tipo = entrada.nextInt();
        
        inprimir.inpresion(tipo,minombre);
        
    }
    
}

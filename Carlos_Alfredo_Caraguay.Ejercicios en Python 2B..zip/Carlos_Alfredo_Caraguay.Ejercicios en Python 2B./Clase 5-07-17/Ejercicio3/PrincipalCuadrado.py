from Cuadrado import Cuadrado
lado = 0
for i in range(1,5):
    c = Cuadrado()
    print("---------------------------------")
    lado = int(input("Ingrese el lado del cuadrado--->"))
    c.agregar_lado(lado)
    c.calcular_area()
    c.calcular_perimetro()
    area = c.calcular_area()
    perimetro = c.calcular_perimetro();

    
    print("El cuadrado con lado:",lado,"\n\tArea=",area,"\n\tPermetro=",perimetro)

input()





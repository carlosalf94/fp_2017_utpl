class Estudiante:
    nombre = ""
    edad = 0
    

def ejercicio4():
	""" Promedio de estudiantes, e imprimir con sus respectivos nombres"""
	notas = [[7, 7, 8], [9,8,10],[10,10,3]]
	info = [["María", "Loja"], ["Luis", "Quito"], ["José", "Cuenca"]]
	promedios = [0, 0, 0]

	for i in range(0, 3):
		promedio = 0.0
		suma = 0
		for j in range(0, 3):
			suma = suma + notas[i][j]
		promedio = suma / 3
		promedios[i] = promedio	

	for k in range(0, 3):
		print("Nombre: %s\nCiudad: %s\nPromedio: %.2f\n" %(info[k][0], info[k][1], promedios[k]))
	print()
		
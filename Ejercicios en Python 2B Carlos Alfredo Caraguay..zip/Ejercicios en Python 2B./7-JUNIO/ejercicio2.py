def ejercicio2():
	""" Imprime arreglo bidimensional en blanco"""
	arreglo = [[1, 2, 3], [11, 22, 33]]
	for i in range(0, 3):
		for j in range(0, 3):
			print(arreglo[i][j])

		print()

def ejercicio7():
	"""hola """
	notas = [[7, 7, 8], [9,8,10],[10,10,3]]
	suma = 0
	opcion = int(input("¿Qué opción desea realizar? 1 , 2 o 3:  "))
	if (opcion == 1):
		for i in range(0, 3):
			for k in range(0, 3):
				if(i == k):
					if(notas[i][k] % 2 != 0):
						suma = suma + notas[i][k]
	if (opcion == 2):
		for i in range(0, 3):
			for k in range(0, 3):
				if(i > k):
					if(notas[i][k] % 2 != 0):
						suma = suma + notas[i][k]
	if (opcion == 3):
		for i in range(0, 3):
			for k in range(0, 3):
				if(i < k):
					if(notas[i][k] % 2 != 0):
						suma = suma + notas[i][k]
	print("La suma es %d" %suma)

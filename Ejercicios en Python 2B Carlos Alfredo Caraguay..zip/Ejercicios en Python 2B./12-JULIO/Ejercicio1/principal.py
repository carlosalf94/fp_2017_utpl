from Estudiante import Estudiante

es1 = Estudiante()
es2 = Estudiante()

suma = 0
prom = 0

es1.nombre = "Rene"
es2.nombre = "Joe"

es1.promedio = 9.2
es2.promedio = 8.5

lista = [9.2, 8.3]

for elemento in lista:
	suma = suma + elemento

prom = suma / 2

print (prom)

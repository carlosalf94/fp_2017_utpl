#Estudiante

class Estudiante:
	nombre = ""
	promedio = 0


# Metodo agregar nombre
def obtener_nombre(self):
	return nombre
# Metodo para obttener el nombre
def obtener_nombre(self):
    return nombre  

# Metodo agregar promedio
def agregar_promedio(self,promedio):
    return promedio
# Metodo obtener promedio
def obtener_promedio(self):
    return self.promedio

# input() 
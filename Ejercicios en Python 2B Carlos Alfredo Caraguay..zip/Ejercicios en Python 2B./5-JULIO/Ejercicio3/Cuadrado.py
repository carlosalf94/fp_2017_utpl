class Cuadrado:
    lado=0

    def agregar_lado(self,l):
        self.lado = l

    def obtener_lado(self):
        return lado;

    def calcular_area(self):
        area = self.lado * self.lado
        return area
    def calcular_perimetro(self):
        perimetro = self.lado + self.lado + self.lado + self.lado;
        return perimetro

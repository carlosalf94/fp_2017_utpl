from Estudiante1 import Estudiante

es1 = Estudiante()
es2 = Estudiante()

suma_edades = 0
promedio = 0
valor_nombre = "Luis"

es1.agregar_nombre(valor_nombre)
es1.agregar_edad(18)
es2.agregar_edad(17)

suma_edades = es1.obtener_edad() + es2.obtener_edad()

promedio = (float(suma_edades)/2)

print(promedio)

input()

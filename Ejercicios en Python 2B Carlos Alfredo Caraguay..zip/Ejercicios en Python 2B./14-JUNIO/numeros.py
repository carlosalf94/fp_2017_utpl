def numeros():
  
        print("Ingrese su nombre")
        nombre = input() 

        print("Tipo de reporte 1 - 2")
        tipo = input() 

        if (tipo == 1)
            presentar_mayusculas (minombre)

        } else {  

            if (tipo == 2)
            presentar_minusculas (minombre)   

        } else { 

            print("No hay reporte") 
            
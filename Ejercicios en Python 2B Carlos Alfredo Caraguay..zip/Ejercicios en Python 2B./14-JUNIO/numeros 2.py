def numeros 2()
    
    print("Ingrese su nombre")
    nombre = input() 
    println("Tipo de reporte 1-2")
    tipo = input()       
        if (opcion==1){
            Presentar_mayusculas(valor2);
}else{

    if (opcion==2){
        Presentar_minusculas(valor2);
        
    }else{

        printf("No hay reporte");
     
